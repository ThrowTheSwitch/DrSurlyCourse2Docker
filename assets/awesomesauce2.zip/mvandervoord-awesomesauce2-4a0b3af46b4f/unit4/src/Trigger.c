#include "Core.h"
#include "Digital.h"
#include "Timer.h"
#include "Trigger.h"

static TRIGGER_T TriggerStyle;
static uint32_t  TriggerTime;
static uint8_t   TriggerPrev;
static uint8_t   TriggerMask;
static uint8_t   TriggerSeq[TRIGGER_MAX_SEQUENCE];
static uint8_t   TriggerSeqLen;
static uint8_t   TriggerSeqPos;
static int       Triggered;

void Trigger_Init()
{
    TriggerStyle  = TRIGGER_BIT_CHANGE;
    TriggerMask   = 0x01;
    TriggerSeq[0] = 0x00;
    TriggerSeqLen = 0;
}

void Trigger_Reset()
{
    Triggered = 0;
    TriggerSeqPos = 0;
    TriggerPrev = Digital_GetBits() & TriggerMask;
}

int Trigger_IsTriggered(void)
{
    uint8_t Current = Digital_GetBits() & TriggerMask;

    //if it's already triggered, say yes.
    if (Triggered)
        return 1;

    //check for latest conditions
    switch(TriggerStyle)
    {
        case TRIGGER_BIT_CHANGE:
            Triggered = (Current != TriggerPrev);
            break;

        case TRIGGER_BIT_STATE:
        case TRIGGER_SEQUENCE:
            if (Current == (TriggerMask & TriggerSeq[TriggerSeqPos]))
            {
                TriggerSeqPos++;
                Triggered = (TriggerSeqPos >= TriggerSeqLen);
            }
            break;

        case TRIGGER_TIMESTAMP:
            Triggered = (Timer_GetStamp() >= TriggerTime);
            break;

        default:
            Triggered = 0;
            break;
    }

    return Triggered;
}

STATUS_T Trigger_OnBitChange(uint8_t MaskToCheck)
{
    TriggerStyle  = TRIGGER_BIT_CHANGE;
    TriggerMask   = MaskToCheck;
    TriggerSeq[0] = 0x00;
    TriggerSeqLen = 0;

    return STATUS_OK;
}

STATUS_T Trigger_OnBitState( uint8_t MaskToCheck, uint8_t MaskStates)
{
    TriggerStyle  = TRIGGER_BIT_STATE;
    TriggerMask   = MaskToCheck;
    TriggerSeq[0] = MaskStates;
    TriggerSeqLen = 1;

    return STATUS_OK;
}

STATUS_T Trigger_OnSequence( uint8_t MaskToCheck, uint8_t* MaskStates, uint8_t Len)
{
    int i;

    if (Len < 1)
        return STATUS_TOO_LOW;
    if (Len > DIGITAL_NUM_CHANS)
        return STATUS_TOO_HIGH;

    TriggerStyle  = TRIGGER_SEQUENCE;
    TriggerMask   = MaskToCheck;
    TriggerSeqLen = Len;
    for (i = 0; i < Len; i++)
        TriggerSeq[i] = MaskStates[i];

    return STATUS_OK;
}

STATUS_T Trigger_OnTimestamp(uint32_t Timestamp)
{
    TriggerStyle = TRIGGER_TIMESTAMP;
    TriggerTime  = Timestamp;

    return STATUS_OK;
}

STATUS_T Trigger_Now(void)
{
    if (Triggered)
        return STATUS_ALREADY_TRIGGERED;

    Triggered = 1;
    return STATUS_OK;
}

