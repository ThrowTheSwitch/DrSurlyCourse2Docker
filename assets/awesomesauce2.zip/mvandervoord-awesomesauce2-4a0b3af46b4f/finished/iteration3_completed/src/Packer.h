#ifndef _PACKER_H
#define _PACKER_H

#define PACKER_MAX_LEN  (75)

char* Packer_AddMsg(char Cmd, char* Data, uint8_t Len);

#endif // _PACKER_H
