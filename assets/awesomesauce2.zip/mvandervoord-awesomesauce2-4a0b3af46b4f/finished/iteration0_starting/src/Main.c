#include "Core.h"
#include "Main.h"

int main(void)
{
    return -1;
}
