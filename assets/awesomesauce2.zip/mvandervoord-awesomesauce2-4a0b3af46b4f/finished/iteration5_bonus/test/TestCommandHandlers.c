#include "Core.h"
#include "unity.h"
#include "CommandHandlers.h"

#include "MockCapture.h"
#include "MockBuffer.h"
#include "MockParams.h"
#include "MockTimer.h"
#include "MockTrigger.h"

BUFFER_T CaptureBuffer;

void setUp(void)
{
}

void tearDown(void)
{
}

void test_CommandHandlers_NeedToImplement(void)
{
    TEST_IGNORE();
}
