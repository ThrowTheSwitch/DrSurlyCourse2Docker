#include "Core.h"
#include "unity.h"
#include "Parser.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Parser_NeedToImplement(void)
{
    TEST_IGNORE();
}
