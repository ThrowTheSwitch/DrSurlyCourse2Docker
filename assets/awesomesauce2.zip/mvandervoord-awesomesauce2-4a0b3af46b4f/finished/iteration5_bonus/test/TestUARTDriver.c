#include "Core.h"
#include "unity.h"

#include "Mockserial_api.h"

#include "UARTDriver.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_TODO(void)
{
    TEST_IGNORE_MESSAGE("Implement Me!");
}
