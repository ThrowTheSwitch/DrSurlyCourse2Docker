#include "Core.h"
#include "unity.h"

#include "MockUARTDriver.h"
#include "MockBuffer.h"
#include "MockParams.h"

#include "CaptureComm.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Capture_NeedToImplement(void)
{
    TEST_IGNORE();
}
