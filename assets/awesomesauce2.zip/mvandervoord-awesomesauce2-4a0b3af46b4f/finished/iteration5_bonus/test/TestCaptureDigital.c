#include "Core.h"
#include "unity.h"

#include "MockBuffer.h"
#include "MockDigital.h"
#include "MockParams.h"

#include "CaptureDigital.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Capture_NeedToImplement(void)
{
    TEST_IGNORE();
}
