#include "Core.h"
#include "unity.h"

#include "MockBuffer.h"
#include "MockParams.h"
#include "MockTimer.h"
#include "MockTrigger.h"
#include "MockLED.h"
#include "MockCaptureAnalog.h"
#include "MockCaptureComm.h"
#include "MockCaptureDigital.h"

#include "Capture.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Capture_NeedToImplement(void)
{
    TEST_IGNORE_MESSAGE("Need to Implement!");
}
