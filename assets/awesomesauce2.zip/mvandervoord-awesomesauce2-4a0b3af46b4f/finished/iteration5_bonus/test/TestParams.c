#include "Core.h"
#include "unity.h"
#include "Params.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Params_NeedToImplement(void)
{
    TEST_IGNORE();
}
