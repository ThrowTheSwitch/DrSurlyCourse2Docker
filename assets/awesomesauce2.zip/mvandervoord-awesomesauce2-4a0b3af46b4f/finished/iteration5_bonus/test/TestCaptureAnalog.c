#include "Core.h"
#include "unity.h"

#include "MockAnalogModel.h"
#include "MockBuffer.h"
#include "MockParams.h"

#include "CaptureAnalog.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Capture_NeedToImplement(void)
{
    TEST_IGNORE();
}
