#include "Core.h"
#include "unity.h"
#include "CommandHardware.h"

#include "MockUSBDriver.h"
#include "MockUtils.h"
#include "MockParser.h"
#include "MockPacker.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_CommandHardware_NeedToImplement(void)
{
    TEST_IGNORE();
}
