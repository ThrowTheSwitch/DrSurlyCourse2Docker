#include "Core.h"
#include "unity.h"

#include "Mockserial_api.h"
#include "MockBuffer.h"

#include "USBDriver.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_TODO(void)
{
    TEST_IGNORE_MESSAGE("Implement Me!");
}
