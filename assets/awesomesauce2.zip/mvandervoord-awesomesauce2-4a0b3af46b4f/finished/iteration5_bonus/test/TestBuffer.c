#include "Core.h"
#include "unity.h"
#include "Buffer.h"

void test_YouCanPutSOmethingInYourBufferAndGetItBackOut(void)
{
    TEST_IGNORE();
}
