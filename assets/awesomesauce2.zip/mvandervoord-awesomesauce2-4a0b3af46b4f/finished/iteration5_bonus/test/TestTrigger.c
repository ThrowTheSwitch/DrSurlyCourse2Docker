#include "Core.h"
#include "unity.h"
#include "Trigger.h"

#include "MockTimer.h"
#include "MockDigital.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Trigger_NeedToImplement(void)
{
    TEST_IGNORE();
}
