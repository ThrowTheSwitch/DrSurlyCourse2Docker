#ifndef _CAPTURE_H
#define _CAPTURE_H

STATUS_T Capture_Init(void);
STATUS_T Capture_Reset(void);
STATUS_T Capture_Arm(void);
void     Capture_Exec(void);
STATUS_T Capture_Status(void);
STATUS_T Capture_GetResult(uint8_t* buffer, uint8_t* len, uint8_t maxLen);

#endif // _CAPTURE_H
