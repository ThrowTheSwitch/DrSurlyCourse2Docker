#ifndef _PARAMS_H
#define _PARAMS_H

typedef enum _PARAM_ID_T
{
    PARAM_DIGITAL_CHANS = 0,
    PARAM_ANALOG_CHANS,
    PARAM_COMM_CHANS,
    PARAM_NUM_SAMPLES,
    PARAM_CAPTURE_RATE,
    PARAM_COM1_BAUD,
    PARAM_COM2_BAUD,
    PARAM_COM3_BAUD,
    PARAM_PULLDOWN,
    PARAM_PULLUP,

    PARAM_MAX
} PARAM_ID_T;

void     Param_Init(void);
uint8_t  Param_Count(void);
uint16_t Param_Get(PARAM_ID_T ParamId);
STATUS_T Param_Set(PARAM_ID_T ParamId, uint16_t Val);
STATUS_T Param_Defaults(void);
STATUS_T Param_Store(void);
STATUS_T Param_Load(void);

#endif // _PARAMS_H
