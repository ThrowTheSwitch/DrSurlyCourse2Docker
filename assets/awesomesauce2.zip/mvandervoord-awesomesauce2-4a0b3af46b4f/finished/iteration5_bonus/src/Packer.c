#include "Core.h"
#include "Packer.h"

static char buffer[75];

char* Packer_AddMsg(char Cmd, char* Data, uint8_t Len)
{
    uint8_t i = 0;

    if (Len > 35)
        return NULL;
    if ((Cmd < 'A') || (Cmd > 'Z'))
        return NULL;

    buffer[i++] = '[';
    buffer[i++] = Cmd;
    if (Len > 10)
        buffer[i++] = (Len - 10 + 'A');
    else
        buffer[i++] = (Len + '0');
    while(Len--)
    {
        buffer[i++] = *Data++;
        buffer[i++] = *Data++;
    }
    buffer[i++] = ']';
    buffer[i++] = 0;

    return buffer;
}
