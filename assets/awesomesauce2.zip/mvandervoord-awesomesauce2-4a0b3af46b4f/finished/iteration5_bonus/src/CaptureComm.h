#ifndef _CAPTURE_COMM_H
#define _CAPTURE_COMM_H

#include "Buffer.h"

STATUS_T CaptureComm_Reset(void);
void     CaptureComm_OnStart(void);
void     CaptureComm_OnStop(void);
STATUS_T CaptureComm_Exec(BUFFER_T* capturebuffer);
STATUS_T CaptureComm_Fetch(BUFFER_T* capturebuffer, uint8_t* buffer, uint8_t* len, uint8_t maxLen);

#endif // _CAPTURE_COMM_H
