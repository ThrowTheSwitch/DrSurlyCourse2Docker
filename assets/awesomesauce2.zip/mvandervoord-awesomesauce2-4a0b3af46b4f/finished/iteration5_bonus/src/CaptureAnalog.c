#include "Core.h"
#include "Buffer.h"
#include "Params.h"
#include "AnalogModel.h"

static uint8_t AnalogChans;

STATUS_T CaptureAnalog_Reset(void)
{
    AnalogChans = Param_Get(PARAM_ANALOG_CHANS);

    if (AnalogChans != 0)
        AnalogModel_Start(AnalogChans);
    else
        AnalogModel_Stop();

    return STATUS_OK;
}

STATUS_T CaptureAnalog_Exec(BUFFER_T* capturebuffer)
{
    uint8_t i;
    uint8_t Num;
    uint16_t Val16;
    STATUS_T Retval;

    if (AnalogChans)
    {
        Num = COUNT_HIGH_BITS8(AnalogChans);
        Retval = Buffer_Put(capturebuffer, 0xC4);
        if (Retval != STATUS_OK)
            return Retval;
        Retval = Buffer_Put(capturebuffer, Num*2);
        if (Retval != STATUS_OK)
            return Retval;

        for (i = 0; i < ANALOG_NUM_CHANS; i++)
        {
            if (AnalogChans & (0x01 << i))
            {
                Val16 = AnalogModel_GetChannel(i);
                Retval = Buffer_Put(capturebuffer, Val16 >> 8);
                if (Retval != STATUS_OK)
                    return Retval;
                else
                    Retval = Buffer_Put(capturebuffer, Val16 & 0x00FF);
                if (Retval != STATUS_OK)
                    return Retval;
            }
        }
    }
    return STATUS_OK;

}

STATUS_T CaptureAnalog_Fetch(BUFFER_T* capturebuffer, uint8_t* buffer, uint8_t* len, uint8_t maxLen)
{
    uint8_t j;
    uint8_t num, val;
    STATUS_T retval;

    if (AnalogChans)
    {
        num = COUNT_HIGH_BITS8(AnalogChans) * 2;
        if (maxLen >= (*len + num + 2))
        {
            buffer = &buffer[*len];
            *len += num + 2;

            //Verify the header of the analog section
            retval = Buffer_Get(capturebuffer, &val);
            if (retval != STATUS_OK)
                return retval;
            if (val != 0xC4)
                return STATUS_MISSING_DATA;

            retval = Buffer_Get(capturebuffer, &val);
            if (retval != STATUS_OK)
                return retval;
            if (val != num)
                return STATUS_MISSING_DATA;

            //Place the header to the analog section
            *buffer++ = 0xC4;
            *buffer++ = val;
            for (j = 0; j < 8; j++)
            {
                if (AnalogChans & (1u << j))
                {
                    retval = Buffer_Get(capturebuffer, (uint8_t*)(buffer++));
                    if (retval != STATUS_OK)
                        return retval;

                    retval = Buffer_Get(capturebuffer, (uint8_t*)(buffer++));
                    if (retval != STATUS_OK)
                        return retval;
                }
            }
        }
    }
    return STATUS_OK;
}
