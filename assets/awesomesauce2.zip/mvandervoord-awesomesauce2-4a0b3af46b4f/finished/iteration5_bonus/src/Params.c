#include "Core.h"
#include "Params.h"

STATIC struct _PARAM_DEF_T
{
    uint16_t Min;
    uint16_t Max;
    uint16_t Default;
} ParamDefs[] =
{
    {       0x00,             0x3F,           0x3F  },    //PARAM_DIGITAL_CHANS
    {       0x00,             0x3F,           0x00  },    //PARAM_ANALOG_CHANS
    {       0x00,             0x07,           0x00  },    //PARAM_COMM_CHANS
    {          0, BUFFER_MAX_BYTES,             16  },    //PARAM_NUM_SAMPLES
    {          0,              255,              4  },    //PARAM_CAPTURE_RATE
    {        300,            57600,           9600  },    //PARAM_COM1_BAUD
    {        300,            57600,           9600  },    //PARAM_COM2_BAUD
    {        300,            57600,           9600  },    //PARAM_COM3_BAUD
    {          0,             0x3F,           0x3F  },    //PARAM_PULLDOWN
    {          0,             0x3F,           0x00  },    //PARAM_PULLUP
};

STATIC uint16_t Params[ PARAM_MAX ];

void Param_Init(void)
{
    Param_Defaults();
}

uint8_t Param_Count(void)
{
    return DIMENSION_OF(ParamDefs);
}

uint16_t Param_Get(PARAM_ID_T ParamId)
{
    if (ParamId >= DIMENSION_OF(Params))
        return 0;

    return Params[ParamId];
}

STATUS_T Param_Set(PARAM_ID_T ParamId, uint16_t Val)
{
    if (ParamId >= DIMENSION_OF(Params))
        return STATUS_INVALID_PARAM;
    if (Val < ParamDefs[ParamId].Min)
        return STATUS_TOO_LOW;
    if (Val > ParamDefs[ParamId].Max)
        return STATUS_TOO_HIGH;

    Params[ParamId] = Val;

    return STATUS_OK;
}

STATUS_T Param_Defaults(void)
{
    uint32_t i;

    for (i=0; i < DIMENSION_OF(Params); i++)
        Params[i] = ParamDefs[i].Default;

    return STATUS_OK;
}

