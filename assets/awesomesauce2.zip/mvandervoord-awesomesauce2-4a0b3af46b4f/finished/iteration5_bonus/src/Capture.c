#include "Core.h"
#include "Buffer.h"
#include "Timer.h"
#include "Trigger.h"
#include "Params.h"
#include "LED.h"
#include "CaptureDigital.h"
#include "CaptureAnalog.h"
#include "CaptureComm.h"
#include "Capture.h"

STATIC BUFFER_T CaptureBuffer;
STATIC uint8_t  CaptureBytes[BUFFER_MAX_BYTES];

static STATUS_T CurrentStatus;
static uint32_t LastCapture;
static uint32_t CaptureRate;
static uint32_t NumSamples;

STATUS_T Capture_Init(void)
{
    Trigger_Init();
    Capture_Reset();

    return Buffer_Init(&CaptureBuffer, CaptureBytes, (uint16_t)(sizeof(CaptureBytes)));
}

STATUS_T Capture_Reset(void)
{
    Trigger_Reset();

    Buffer_Clear(&CaptureBuffer);

    CaptureRate = (uint32_t)Param_Get(PARAM_CAPTURE_RATE);
    NumSamples  = (uint32_t)Param_Get(PARAM_NUM_SAMPLES);

    CaptureDigital_Reset();
    CaptureAnalog_Reset();
    CaptureComm_Reset();

    LastCapture = Timer_GetStamp();
    CurrentStatus = STATUS_NOT_ARMED;

    return STATUS_OK;
}

STATUS_T Capture_Arm(void)
{
    if (CurrentStatus <= STATUS_NONE_YET)
    {
        CurrentStatus = STATUS_NONE_YET;
        return STATUS_OK;
    }
    else
    {
        return STATUS_ALREADY_TRIGGERED;
    }
}

void Capture_Exec(void)
{
    STATUS_T Retval;

    //We're armed and looking for a trigger
    if ((CurrentStatus == STATUS_NONE_YET) && (Trigger_IsTriggered()))
    {
        CaptureComm_OnStart();
        CurrentStatus = STATUS_CAPTURING;
    }

    //We're capturing periodically while in the capturing state
    if ((CurrentStatus == STATUS_CAPTURING) && (Timer_GetDiff(LastCapture) > CaptureRate))
    {
        //Update Capture Timestamp
        LastCapture = Timer_GetStamp();

        //Determine if we're done yet
        if (NumSamples)
        {
            --NumSamples;
        }
        else
        {
            CaptureComm_OnStop();
            CurrentStatus = STATUS_OK;
            return;
        }

        Retval = CaptureDigital_Exec(&CaptureBuffer);
        if (Retval == STATUS_OK)
        {
            Retval = CaptureAnalog_Exec(&CaptureBuffer);
            if (Retval == STATUS_OK)
            {
                Retval = CaptureComm_Exec(&CaptureBuffer);
                if (Retval != STATUS_OK)
                    CurrentStatus = Retval;
            }
            else
            {
                CurrentStatus = Retval;
            }
        }
        else
        {
            CurrentStatus = Retval;
        }
    }

    LED_SetByStatus(CurrentStatus);
}

STATUS_T Capture_GetResult(uint8_t* buffer, uint8_t* len, uint8_t maxLen)
{
    STATUS_T retval = STATUS_OK;

    //start with a length of zero for our response
    *len = 0;

    //Add Digital if Requested
    retval = CaptureDigital_Fetch(&CaptureBuffer, buffer, len, maxLen);
    if (retval != STATUS_OK)
        return retval;

    //Add Analog if Requested
    retval = CaptureAnalog_Fetch(&CaptureBuffer, buffer, len, maxLen);
    if (retval != STATUS_OK)
        return retval;

    //Add Comm if Requested
    retval = CaptureComm_Fetch(&CaptureBuffer, buffer, len, maxLen);
    if (retval != STATUS_OK)
        return retval;

    return retval;
}

STATUS_T Capture_Status(void)
{
    return CurrentStatus;
}
