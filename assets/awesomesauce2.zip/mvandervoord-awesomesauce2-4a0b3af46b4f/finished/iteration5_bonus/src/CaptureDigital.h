#ifndef _CAPTURE_DIGITAL_H
#define _CAPTURE_DIGITAL_H

#include "Buffer.h"

STATUS_T CaptureDigital_Reset(void);
STATUS_T CaptureDigital_Exec(BUFFER_T* capturebuffer);
STATUS_T CaptureDigital_Fetch(BUFFER_T* capturebuffer, uint8_t* buffer, uint8_t* len, uint8_t maxLen);

#endif // _CAPTURE_DIGITAL_H
