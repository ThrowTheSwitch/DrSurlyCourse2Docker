#include "Core.h"
#include "CommandConductor.h"
#include "CommandHandlers.h"
#include "Buffer.h"
#include "Timer.h"
#include "Trigger.h"
#include "Params.h"
#include "Capture.h"

#include <string.h>

void CommandHandler_Init(void)
{

}

STATUS_T CommandHandlerArm(MESSAGE_T* Msg)
{
    if (Msg->Len != 0)
        return STATUS_INVALID_ARG;

    return Capture_Arm();
}

STATUS_T CommandHandlerClock(MESSAGE_T* Msg)
{
    uint32_t Stamp;

    //Fetch the current time if empty
    if (Msg->Len == 0)
    {
        Stamp = Timer_GetStamp();
        Msg->Data[0] = UINT32_BYTE3( Stamp );
        Msg->Data[1] = UINT32_BYTE2( Stamp );
        Msg->Data[2] = UINT32_BYTE1( Stamp );
        Msg->Data[3] = UINT32_BYTE0( Stamp );
        Msg->Len = 4;
    }
    else //Set the time
    {
        if (Msg->Len < 4)
            return STATUS_MISSING_ARG;
        if (Msg->Len > 4)
            return STATUS_EXTRA_ARG;
        Stamp  = BYTE3_TO_UINT32( Msg->Data[0] );
        Stamp |= BYTE2_TO_UINT32( Msg->Data[1] );
        Stamp |= BYTE1_TO_UINT32( Msg->Data[2] );
        Stamp |= BYTE0_TO_UINT32( Msg->Data[3] );
        Timer_SetStamp(Stamp);
    }

    return STATUS_OK;
}

STATUS_T CommandHandlerDefaults(MESSAGE_T* Msg)
{
    if (Msg->Len != 0)
        return STATUS_INVALID_ARG;

    Param_Defaults();
    return Capture_Reset();
}

STATUS_T CommandHandlerParam(MESSAGE_T* Msg)
{
    STATUS_T retval = STATUS_OK;
    uint16_t param;

    switch(Msg->Len)
    {
        case 0: //Return Num Params
            Msg->Data[0] = Param_Count();
            Msg->Len = 1;
            break;
        case 1: //Return Param Value for Param Specified
            param = Param_Get((PARAM_ID_T)(Msg->Data[0]));
            if ((param & 0xFF00) != 0)
            {
                Msg->Data[1] = (uint8_t)((param >> 8) & 0x00FF);
                Msg->Data[2] = (uint8_t)(param & 0x00FF);
                Msg->Len = 3;
            }
            else
            {
                Msg->Data[1] = (uint8_t)(param & 0x00FF);
                Msg->Len = 2;
            }
            break;
        case 2: //Set Param Value for Param Specified
            param = (uint16_t)(Msg->Data[1]);
            retval = Param_Set((PARAM_ID_T)(Msg->Data[0]), param);
            break;
        case 3: //Set Param Value for Param Specified
            param = ((uint16_t)(Msg->Data[1]) << 8) | (uint16_t)(Msg->Data[2]);
            retval = Param_Set((PARAM_ID_T)(Msg->Data[0]), param);
            break;
        default:
            return STATUS_TOO_HIGH;
    }

    return retval;
}

STATUS_T CommandHandlerResults(MESSAGE_T* Msg)
{
    STATUS_T retval, status;

    if (Msg->Len > 0)
        return STATUS_INVALID_ARG;

    //Grab the next snapshot of data
    retval = Capture_GetResult((uint8_t*)(Msg->Data), (uint8_t*)(&Msg->Len), COMMAND_MAX_LEN);

    //If no results AND it's not because we're waiting on more, reset back to disarmed state
    if (retval != STATUS_OK)
    {
        status = Capture_Status();
        if ((status != STATUS_NONE_YET) && (status != STATUS_CAPTURING))
        {
            Capture_Reset();
        }
    }

    return retval;
}

STATUS_T CommandHandlerTrigger(MESSAGE_T* Msg)
{
    uint32_t timestamp;
    STATUS_T retval = STATUS_UNKNOWN_ERR;

    if (Msg->Len < 1)
        return STATUS_MISSING_ARG;

    TRIGGER_T TrigType = Msg->Data[0];

    switch(TrigType)
    {
        case TRIGGER_NONE:
            if (Msg->Len != 1)
                return STATUS_EXTRA_ARG;
            return Trigger_Now();
            break;

        case TRIGGER_BIT_CHANGE:
            if (Msg->Len < 2)
                return STATUS_MISSING_ARG;
            if (Msg->Len > 2)
                return STATUS_EXTRA_ARG;
            retval = Trigger_OnBitChange(Msg->Data[1]);
            break;

        case TRIGGER_BIT_STATE:
            if (Msg->Len < 3)
                return STATUS_MISSING_ARG;
            if (Msg->Len > 3)
                return STATUS_EXTRA_ARG;
            retval = Trigger_OnBitState(Msg->Data[1], Msg->Data[2]);
            break;

        case TRIGGER_SEQUENCE:
            if (Msg->Len < 3)
                return STATUS_MISSING_ARG;
            retval = Trigger_OnSequence(Msg->Data[1], (uint8_t*)(&Msg->Data[2]), Msg->Len - 2);
            break;

        case TRIGGER_TIMESTAMP:
            if (Msg->Len < 5)
                return STATUS_MISSING_ARG;
            if (Msg->Len > 5)
                return STATUS_EXTRA_ARG;
            timestamp  = BYTE3_TO_UINT32( Msg->Data[0] );
            timestamp |= BYTE2_TO_UINT32( Msg->Data[1] );
            timestamp |= BYTE1_TO_UINT32( Msg->Data[2] );
            timestamp |= BYTE0_TO_UINT32( Msg->Data[3] );
            retval = Trigger_OnTimestamp(timestamp);
            break;

        default:
            return STATUS_TOO_HIGH;
    }

    if (retval == STATUS_OK)
    {
        retval = Capture_Reset();
    }

    return retval;
}

STATUS_T CommandHandlerVersion(MESSAGE_T* Msg)
{
    Msg->Data[0] = VERSION_MAJOR;
    Msg->Data[1] = VERSION_MINOR;
    Msg->Len     = 2;

    return STATUS_OK;
}

