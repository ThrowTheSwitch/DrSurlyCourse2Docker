#include "Core.h"
#include "LED.h"

#define LED_PORT    LPC_GPIO1
#define LED_1_BIT   (18)
#define LED_2_BIT   (20)
#define LED_3_BIT   (21)
#define LED_4_BIT   (23)

#define LED_PINSEL   LPC_PINCON->PINSEL3
#define LED_PINMODE  LPC_PINCON->PINMODE3

#define LED_PIN_BIT(bit) (0x3u << ((bit & 0x0F) << 1))

//Map the LED_ID_T index to the actual port bit to drive
const int LED_BitMap[] = { LED_1_BIT, LED_2_BIT, LED_3_BIT, LED_4_BIT };

static uint8_t BlinkMask;

void LED_Init(void)
{
    BlinkMask = 0xF;

    //We're just going to set LED 1 to signify we've started up... everything else starts low.
    LED_PORT->FIOSET  = BIT_TO_MASK(LED_1_BIT);
    LED_PORT->FIOCLR  = BIT_TO_MASK(LED_2_BIT) | BIT_TO_MASK(LED_3_BIT) | BIT_TO_MASK(LED_4_BIT);
    LED_PORT->FIODIR |= BIT_TO_MASK(LED_1_BIT) | BIT_TO_MASK(LED_2_BIT) | BIT_TO_MASK(LED_3_BIT) | BIT_TO_MASK(LED_4_BIT);

    //Clear pin select bits for bits we plan to use to make them GPIO pins
    LED_PINSEL = ~( LED_PIN_BIT(LED_1_BIT) | LED_PIN_BIT(LED_2_BIT) | LED_PIN_BIT(LED_3_BIT) | LED_PIN_BIT(LED_4_BIT));

    //Set the mode for the bits we plan to use to make them all use pulldown resistors
    LED_PINMODE = ~( LED_PIN_BIT(LED_1_BIT) | LED_PIN_BIT(LED_2_BIT) | LED_PIN_BIT(LED_3_BIT) | LED_PIN_BIT(LED_4_BIT));
}

void LED_Exec(void)
{
    int i;
    static int toggle = 0;

    for (i = 0; i < NUM_LED; i++)
    {
        if (BIT_TO_MASK8(i) & BlinkMask)
        {
            if ((toggle & 1) == 1)
                LED_PORT->FIOSET = BIT_TO_MASK(LED_BitMap[i]);
            else
                LED_PORT->FIOCLR = BIT_TO_MASK(LED_BitMap[i]);
        }
    }
    ++toggle;
}

void LED_On(LED_ID_T num)
{
    if (num >= NUM_LED)
        return;

    BlinkMask &= ~BIT_TO_MASK8(num);
    LED_PORT->FIOSET = BIT_TO_MASK(LED_BitMap[num]);
}

void LED_Off(LED_ID_T num)
{
    if (num >= NUM_LED)
        return;

    BlinkMask &= ~BIT_TO_MASK8(num);
    LED_PORT->FIOCLR = BIT_TO_MASK(LED_BitMap[num]);
}

void LED_Blink(LED_ID_T num)
{
    if (num >= NUM_LED)
        return;

    BlinkMask |= BIT_TO_MASK8(num);
}

void LED_Toggle(LED_ID_T num)
{
    uint32_t mask;
    if (num >= NUM_LED)
        return;

    BlinkMask &= ~BIT_TO_MASK8(num);

    mask = BIT_TO_MASK(LED_BitMap[num]);
    if ((LED_PORT->FIOPIN & mask) == mask)
        LED_PORT->FIOCLR = mask;
    else
        LED_PORT->FIOSET = mask;
}

void LED_SetByStatus(STATUS_T status)
{
    static uint8_t LastOnMask = 0;
    uint8_t OnMask = 0;
    uint8_t i;

    switch(status)
    {
        case STATUS_NOT_ARMED:
            BlinkMask = BIT_TO_MASK8(LED_IDLE);
            break;

        case STATUS_NONE_YET:
            OnMask = BIT_TO_MASK8(LED_IDLE);
            BlinkMask = BIT_TO_MASK8(LED_ARMED);
            break;

        case STATUS_CAPTURING:
            OnMask = BIT_TO_MASK8(LED_IDLE) | BIT_TO_MASK8(LED_ARMED);
            BlinkMask = BIT_TO_MASK8(LED_CAPTURING);
            break;

        case STATUS_OK:
            OnMask = BIT_TO_MASK8(LED_IDLE) | BIT_TO_MASK8(LED_ARMED) | BIT_TO_MASK8(LED_CAPTURING);
            BlinkMask = BIT_TO_MASK8(LED_COMPLETE);
            break;

        default:
            BlinkMask = BIT_TO_MASK8(LED_IDLE) | BIT_TO_MASK8(LED_COMPLETE);
            break;
    }

    if (LastOnMask != OnMask)
    {
        for (i = 0; i < NUM_LED; i++)
        {
            if (OnMask & (1 << i))
                LED_On(i);
            else
                LED_Off(i);
        }
        LastOnMask = OnMask;
    }
}
