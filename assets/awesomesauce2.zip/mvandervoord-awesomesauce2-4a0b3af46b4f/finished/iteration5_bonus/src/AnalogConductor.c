
#include "Core.h"
#include "AnalogModel.h"
#include "AnalogHardware.h"
#include "AnalogConductor.h"

static uint8_t  AnalogChans;

void AnalogConductor_Init(void)
{
    AnalogChans = 0;

    AnalogModel_Init();
    AnalogHardware_Init();
}

void AnalogConductor_Exec(void)
{
    uint8_t i;
    uint16_t Value;/*
    uint8_t NewChans;

    //Enable / Disable Hardware Channels As Needed
    NewChans = AnalogModel_ShouldBeRunning();
    if (NewChans != AnalogChans)
    {
        AnalogHardware_SetChans(NewChans);
        AnalogChans = NewChans;
    }*/

    //Check up on the Analog Channels
    for (i=0; i < ANALOG_NUM_CHANS; i++)
    {
        if (AnalogHardware_IsReady(i) == STATUS_OK)
        {
            Value = AnalogHardware_GetReading(i);
            AnalogModel_AddReading(i, Value);
        }
    }
}

