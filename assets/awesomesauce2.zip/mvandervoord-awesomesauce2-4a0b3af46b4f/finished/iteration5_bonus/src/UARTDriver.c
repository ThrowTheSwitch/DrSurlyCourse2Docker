
#include "Core.h"
#include "UARTDriver.h"
#include "serial_api.h"


STATIC BOOL     initialized[UART_NUM_PORTS];
STATIC serial_t serial[UART_NUM_PORTS];

void UARTDriver_Init(void)
{
    int i;

    for (i=0; i < UART_NUM_PORTS; i++)
    {
        initialized[i] = FALSE;
    }
}

void UARTDriver_Exec(void)
{
    //Nothing to do here
}

STATUS_T UARTDriver_Enable(UART_PORT_T port)
{
    PinName tx_pin;
    PinName rx_pin;

    switch(port)
    {
        case 0:
            tx_pin = p13;
            rx_pin = p14;
            break;

        case 1:
            tx_pin = p28;
            rx_pin = p27;
            break;

        case 2:
            tx_pin = p9;
            rx_pin = p10;
            break;

        default:
            return STATUS_UART_BAD_PORT;
    }

    serial_init(&serial[port], tx_pin, rx_pin);
    serial_clear(&serial[port]);

    initialized[port] = TRUE;

    return STATUS_OK;
}

STATUS_T UARTDriver_Disable(UART_PORT_T port)
{
    if (port >= UART_NUM_PORTS)
        return STATUS_UART_BAD_PORT;

    initialized[port] = FALSE;

    return STATUS_OK;
}

STATUS_T UARTDriver_PutChar(UART_PORT_T port, char Val)
{
    if (port >= UART_NUM_PORTS)
        return STATUS_UART_BAD_PORT;

    serial_putc(&serial[port], Val);

    return STATUS_OK;
}

char UARTDriver_GetChar(UART_PORT_T port)
{
    if (port >= UART_NUM_PORTS)
        return 0x00;

    return serial_getc(&serial[port]);
}

BOOL UARTDriver_Connected(UART_PORT_T port)
{
    if (port >= UART_NUM_PORTS)
        return FALSE;

    return initialized[port];
}

BOOL UARTDriver_OkayToRead(UART_PORT_T port)
{
    if (port >= UART_NUM_PORTS)
        return FALSE;

    return (serial_readable(&serial[port]));
}

BOOL UARTDriver_OkayToWrite(UART_PORT_T port)
{
    if (port >= UART_NUM_PORTS)
        return FALSE;

    return (serial_writable(&serial[port]));
}
