#ifndef _TRIGGER_H
#define _TRIGGER_H

#define TRIGGER_MAX_SEQUENCE    8

typedef enum _TRIGGER_T
{
    TRIGGER_NONE,
    TRIGGER_BIT_CHANGE,
    TRIGGER_BIT_STATE,
    TRIGGER_SEQUENCE,
    TRIGGER_TIMESTAMP,

    TRIGGER_MAX
} TRIGGER_T;

void Trigger_Init(void);
void Trigger_Reset(void);
int  Trigger_IsTriggered(void);

STATUS_T Trigger_OnBitChange(uint8_t MaskToCheck);
STATUS_T Trigger_OnBitState( uint8_t MaskToCheck, uint8_t MaskStates);
STATUS_T Trigger_OnSequence( uint8_t MaskToCheck, uint8_t* MaskStates, uint8_t Len);
STATUS_T Trigger_OnTimestamp(uint32_t Timestamp);
STATUS_T Trigger_Now(void);

#endif // _TRIGGER_H
