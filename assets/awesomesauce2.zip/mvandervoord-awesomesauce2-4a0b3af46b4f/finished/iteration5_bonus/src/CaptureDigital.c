#include "Core.h"
#include "Buffer.h"
#include "Params.h"
#include "Digital.h"

static uint8_t DigitalChans;

STATUS_T CaptureDigital_Reset(void)
{
    uint8_t PullUp, PullDown;

    DigitalChans = Param_Get(PARAM_DIGITAL_CHANS);
    PullUp       = Param_Get(PARAM_PULLUP);
    PullDown     = Param_Get(PARAM_PULLDOWN);

    if (DigitalChans)
    {
        Digital_ConfigResistors(PullUp, PullDown);
    }

    return STATUS_OK;
}

STATUS_T CaptureDigital_Exec(BUFFER_T* capturebuffer)
{
    uint8_t Val8;
    STATUS_T Retval;

    if (DigitalChans)
    {
        Val8 = Digital_GetBits() & DigitalChans;
        Retval = Buffer_Put(capturebuffer, Val8);
        if (Retval != STATUS_OK)
            return Retval;
    }
    return STATUS_OK;
}

STATUS_T CaptureDigital_Fetch(BUFFER_T* capturebuffer, uint8_t* buffer, uint8_t* len, uint8_t maxLen)
{
    STATUS_T retval = STATUS_OK;

    if (DigitalChans)
    {
        if ((*len + 1) >= maxLen)
            return STATUS_OVERFLOW;

        buffer = buffer + *len;

        retval = Buffer_Get(capturebuffer, (uint8_t*)(buffer++));
        if (retval == STATUS_OK)
            *len += 1;
    }

    return retval;
}
