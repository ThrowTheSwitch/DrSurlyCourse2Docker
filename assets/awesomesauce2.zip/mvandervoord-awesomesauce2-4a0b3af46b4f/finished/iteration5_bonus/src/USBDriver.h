#ifndef _USBDRIVER_H
#define _USBDRIVER_H

void USBDriver_Init(void);
void USBDriver_Exec(void);
void USBDriver_PutChar(char Val);
char USBDriver_GetChar(void);

BOOL USBDriver_Connected(void);
BOOL USBDriver_OkayToRead(void);
BOOL USBDriver_OkayToWrite(void);

#endif // _USBDRIVER_H
