#ifndef _CAPTURE_ANALOG_H
#define _CAPTURE_ANALOG_H

#include "Buffer.h"

STATUS_T CaptureAnalog_Reset(void);
STATUS_T CaptureAnalog_Exec(BUFFER_T* capturebuffer);
STATUS_T CaptureAnalog_Fetch(BUFFER_T* capturebuffer, uint8_t* buffer, uint8_t* len, uint8_t maxLen);

#endif // _CAPTURE_ANALOG_H
