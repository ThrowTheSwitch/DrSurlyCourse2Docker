#include "Core.h"
#include "Buffer.h"
#include "Params.h"
#include "UARTDriver.h"

static uint8_t CommChans;
static uint8_t Scratch[64]; //TODO smarter define here

STATUS_T CaptureComm_Reset(void)
{
    CommChans = Param_Get(PARAM_COMM_CHANS);

    return STATUS_OK;
}

void CaptureComm_OnStart(void)
{
    uint8_t i;

    for (i=0; i < UART_NUM_PORTS; i++)
    {
        if (CommChans & (0x01 << i))
        {
            UARTDriver_Enable(i);
        }
    }
}

void CaptureComm_OnStop(void)
{
    int8_t i;

    for (i=0; i < UART_NUM_PORTS; i++)
    {
        UARTDriver_Disable(i);
    }
}

STATUS_T CaptureComm_Exec(BUFFER_T* capturebuffer)
{
    uint8_t i, j;
    uint8_t Val8;
    STATUS_T Retval;

    if (CommChans)
    {
        for (i=0; i < UART_NUM_PORTS; i++)
        {
            if (CommChans & (0x01 << i))
            {
                Val8 = 1;
                while (UARTDriver_OkayToRead(i) && (Val8 < sizeof(Scratch)))
                {
                    Scratch[Val8++] = UARTDriver_GetChar(i);
                }

                //Append Length (not including length byte) With Start of StrFix Tag
                Scratch[0] = (Val8 - 1) | 0xA0;

                //Append Values
                for (j=0; j <= Val8; j++)
                {
                    Retval = Buffer_Put(capturebuffer, Scratch[j]);
                    if (STATUS_OK != Retval)
                        return Retval;
                }
            }
        }
    }
    return STATUS_OK;
}

STATUS_T CaptureComm_Fetch(BUFFER_T* capturebuffer, uint8_t* buffer, uint8_t* len, uint8_t maxLen)
{
    uint8_t num, val, j, k;
    STATUS_T retval;

    for (j = 0; j < 8; j++)
    {
        if (CommChans & (1u << j))
        {
            retval = Buffer_Get(capturebuffer, (uint8_t*)(&val));
            if (retval != STATUS_OK)
                return retval;
            if ((val & 0xE0) != 0xA0)
                return STATUS_MISSING_DATA;

            num = val & 0x1F;

            if ((*len + num + 1) >= maxLen)
                return STATUS_OVERFLOW;

            buffer = buffer + *len;
            *len += num + 1;
            *buffer++ = val;

            for (k = 0; k < num; k++)
            {
                retval = Buffer_Get(capturebuffer, (uint8_t*)(buffer++));
                if (retval != STATUS_OK)
                    return retval;
            }
        }
    }
    return STATUS_OK;
}
