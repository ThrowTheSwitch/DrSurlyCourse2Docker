#include "unity.h"
#include "Core.h"
#include "Trigger.h"

void setUp(void)
{
    Trigger_Init();
}

void tearDown(void)
{
}

void test_Trigger_IsTriggered_should_BeFalseWhenJustInit(void)
{
    TEST_ASSERT_FALSE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_BeFalseWhenJustArmed(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());

    TEST_ASSERT_FALSE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_BeFalseWhenAttemptToTriggerAndUnarmed(void)
{
    TEST_ASSERT_EQUAL( STATUS_NOT_ARMED, Trigger_Now());

    TEST_ASSERT_FALSE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_BeTrueWhenArmedAndThenTriggered(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_ReportIfAlreadyArmedButWillRemainArmed(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_ALREADY_ARMED, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_NotBeTriggerableWhenDisarmed(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Disarm());
    TEST_ASSERT_EQUAL( STATUS_NOT_ARMED, Trigger_Now());

    TEST_ASSERT_FALSE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_BeAbleToArmAfterBeingDisarmed(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Disarm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_NotAllowMultipleTriggersOffOneArm(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());
    TEST_ASSERT_EQUAL( STATUS_ALREADY_TRIGGERED, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_AllowRearmAfterTriggering(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );

    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());

    TEST_ASSERT_FALSE( Trigger_IsTriggered() );

    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );
}

void test_Trigger_IsTriggered_should_AllowRearmAfterTriggeringAndDisarm(void)
{
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );

    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Disarm());

    TEST_ASSERT_FALSE( Trigger_IsTriggered() );

    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Arm());
    TEST_ASSERT_EQUAL( STATUS_OK, Trigger_Now());

    TEST_ASSERT_TRUE( Trigger_IsTriggered() );
}
