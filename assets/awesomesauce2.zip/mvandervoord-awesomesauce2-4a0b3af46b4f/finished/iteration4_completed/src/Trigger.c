#include "Core.h"
#include "Trigger.h"

static STATUS_T TriggerState;

void Trigger_Init(void)
{
    TriggerState = STATUS_NOT_ARMED;
}

void Trigger_Reset(void)
{
    TriggerState = STATUS_NOT_ARMED;
}

int  Trigger_IsTriggered(void)
{
    return (TriggerState == STATUS_CAPTURING);
}

STATUS_T Trigger_Disarm(void)
{
    TriggerState = STATUS_NOT_ARMED;
    return STATUS_OK;
}

STATUS_T Trigger_Arm(void)
{
    if (TriggerState != STATUS_NONE_YET)
    {
        TriggerState = STATUS_NONE_YET;
        return STATUS_OK;
    }
    else
    {
        return STATUS_ALREADY_ARMED;
    }
}

STATUS_T Trigger_OnBitChange(uint8_t MaskToCheck)
{
    return STATUS_UNKNOWN_ERR;
}

STATUS_T Trigger_OnBitState( uint8_t MaskToCheck, uint8_t MaskStates)
{
    return STATUS_UNKNOWN_ERR;
}

STATUS_T Trigger_OnSequence( uint8_t MaskToCheck, uint8_t* MaskStates, uint8_t Len)
{
    return STATUS_UNKNOWN_ERR;
}

STATUS_T Trigger_OnTimestamp(uint32_t Timestamp)
{
    return STATUS_UNKNOWN_ERR;
}

STATUS_T Trigger_Now(void)
{
    if (TriggerState == STATUS_NONE_YET)
    {
        TriggerState = STATUS_CAPTURING;
        return STATUS_OK;
    }
    else if (TriggerState == STATUS_CAPTURING)
    {
        return STATUS_ALREADY_TRIGGERED;
    }
    else
    {
        return STATUS_NOT_ARMED;
    }
}
