#include "Core.h"
#include "AnalogModel.h"
#include "Digital.h"
#include "Buffer.h"
#include "Trigger.h"
#include "Capture.h"

static BUFFER_T CaptureBuffer;
static uint8_t  CaptureBytes[BUFFER_MAX_BYTES];

void Capture_Init(void)
{
    Trigger_Init();
    Buffer_Init(&CaptureBuffer, CaptureBytes, (uint16_t)(sizeof(CaptureBytes)));
    //Capture_Reset();
}

void Capture_Exec(void)
{
    uint8_t i;
    uint16_t data;

    //Nothing To Do if Not Triggered
    if (!Trigger_IsTriggered())
        return;

    //Capture Digital
    if (STATUS_OK != Buffer_Put(&CaptureBuffer, Digital_GetBits()))
        return;

    //Put Analog Header
    if (STATUS_OK != Buffer_Put(&CaptureBuffer, 0xC4))
        return;
    if (STATUS_OK != Buffer_Put(&CaptureBuffer, (uint8_t)(ANALOG_NUM_CHANS * 2)))
        return;

    //Capture Analog
    for (i=0; i < ANALOG_NUM_CHANS; i++)
    {
        data = AnalogModel_GetChannel( i );
        if (STATUS_OK != Buffer_Put(&CaptureBuffer, (uint8_t)(data >> 8)))
            return;
        if (STATUS_OK != Buffer_Put(&CaptureBuffer, (uint8_t)(data & 0x00FF)))
            return;
    }
}

STATUS_T Capture_GetResult(uint8_t* buffer, uint8_t* len, uint8_t maxLen)
{
    uint8_t i;
    STATUS_T status;

    *len = ANALOG_NUM_CHANS * 2 + 2 + 1;

    //Grab data from buffer
    for (i=0; i < *len; i++)
    {
        status = Buffer_Get(&CaptureBuffer, buffer++);
        if (status != STATUS_OK)
            return status;
    }

    return STATUS_OK;
}

STATUS_T Capture_Reset(void)
{
    Buffer_Clear(&CaptureBuffer);

    return STATUS_OK;
}
