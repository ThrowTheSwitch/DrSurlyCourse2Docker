#include "Poster.h"

void MockPoster_Init(void);
void MockPoster_Verify(void);

void PostNumber_Expect(int expected_number);
