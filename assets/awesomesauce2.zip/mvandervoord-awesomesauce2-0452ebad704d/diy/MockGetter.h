#include "Getter.h"

void MockGetter_Init(void);
void MockGetter_Verify(void);

void GetNumber_ExpectAndReturn(int return_value);
