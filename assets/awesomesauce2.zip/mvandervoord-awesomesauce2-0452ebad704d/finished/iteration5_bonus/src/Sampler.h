#ifndef _SAMPLER_H
#define _SAMPLER_H

void Sampler_Init(void);
void Sampler_Reset(void);
BOOL Sampler_IsReady(void);

#endif // _SAMPLER_H
