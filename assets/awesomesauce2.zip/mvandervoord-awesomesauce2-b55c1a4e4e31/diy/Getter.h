#ifndef GETTER_H
#define GETTER_H

int GetNumber(void);

#endif
