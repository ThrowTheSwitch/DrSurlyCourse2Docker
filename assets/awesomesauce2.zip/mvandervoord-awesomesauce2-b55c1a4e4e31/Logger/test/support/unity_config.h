#include <stdio.h>

#define UNITY_OUTPUT_CHAR(a) print_uart0(a)
