#ifndef _MAIN_H
#define _MAIN_H

int main(void);

#endif // _MAIN_H
