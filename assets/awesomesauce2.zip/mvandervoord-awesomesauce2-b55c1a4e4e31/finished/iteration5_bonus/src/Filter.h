#ifndef _FILTER_H
#define _FILTER_H

uint16_t Filter_AddVal(uint16_t PrevVal, uint16_t NewVal, uint16_t Numerator, uint16_t Denominator);

#endif // _FILTER_H
