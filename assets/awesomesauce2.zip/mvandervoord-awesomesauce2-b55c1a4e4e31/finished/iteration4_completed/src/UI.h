#ifndef _UI_H
#define _UI_H

void UI_Init(void);
void UI_Exec(void);

#endif // _UI_H
