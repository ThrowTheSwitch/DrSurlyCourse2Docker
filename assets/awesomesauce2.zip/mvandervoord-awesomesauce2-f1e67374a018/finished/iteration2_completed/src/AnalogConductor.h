#ifndef _ANALOGCONDUCTOR_H
#define _ANALOGCONDUCTOR_H

void AnalogConductor_Init(void);
void AnalogConductor_Exec(void);

#endif // _ANALOGCONDUCTOR_H
