#ifndef POSTER_H
#define POSTER_H

void PostNumber(int number);

#endif
