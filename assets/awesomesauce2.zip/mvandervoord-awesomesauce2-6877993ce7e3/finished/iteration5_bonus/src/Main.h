#ifndef _MAIN_H
#define _MAIN_H

#ifndef TEST
int main(void);
#else
int TestableMain(void);
#endif

#endif // _MAIN_H
