#ifndef DOUBLE_AND_PASS_H
#define DOUBLE_AND_PASS_H

void DoubleAndPass(void);

#endif
