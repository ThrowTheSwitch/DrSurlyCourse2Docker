#include "Core.h"
#include "unity.h"
#include "Main.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Main_NeedToImplement(void)
{
    TEST_IGNORE_MESSAGE("Main Not Implemented");
}

