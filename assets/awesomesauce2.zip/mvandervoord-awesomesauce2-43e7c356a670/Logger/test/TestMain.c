#include "Core.h"
#include "unity.h"
#include "Main.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_Main_NeedToImplement(void)
{
    //
    // NOTE: Do not attempt to test main() in Main.c directly.
    //       See Lecture 9 for how to handle this special case.
    //
  
    TEST_IGNORE_MESSAGE("Main Not Implemented");
}

