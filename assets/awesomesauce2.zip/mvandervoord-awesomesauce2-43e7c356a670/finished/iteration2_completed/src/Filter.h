#ifndef _FILTER_H
#define _FILTER_H

uint16_t Filter_AddVal(uint16_t PrevVal, uint16_t NewVal);

#endif // _FILTER_H
